﻿using Love;

namespace AudioVisualizer
{
    class Program
    {
        static void Main(string[] args)
        {
            Boot.Run(new FreqVisualizerMathNet());
        }
    }
}
